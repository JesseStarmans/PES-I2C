/*
 * i2c_slave.c
 *
 *  Created on: Mar 26, 2024
 *      Author: gdjon
 */


#include "main.h"
#include "i2c_slave.h"

extern I2C_HandleTypeDef hi2c1;

