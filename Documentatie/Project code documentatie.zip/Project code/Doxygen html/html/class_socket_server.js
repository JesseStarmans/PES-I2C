var class_socket_server =
[
    [ "SocketServer", "class_socket_server.html#a4f50740e8f8ae399c1cd22c3e688ffc2", null ],
    [ "~SocketServer", "class_socket_server.html#af0e595690e453ef4b8e8da174069aba9", null ],
    [ "closeClientConnection", "class_socket_server.html#a08444127be013b095c6229f5cb8124d6", null ],
    [ "receiveData", "class_socket_server.html#ab5ea735b43721aad6c62dce0d9ea3545", null ],
    [ "sendData", "class_socket_server.html#a5f49b9a12fd499fde0cc68f6f4ef256f", null ],
    [ "serverAccept", "class_socket_server.html#a58362554d3c65ed2ca71e65651ed0a53", null ],
    [ "serverListen", "class_socket_server.html#ab742c7e5d268cbc174fb6af0f3fe63df", null ],
    [ "setupWemosIP", "class_socket_server.html#ad8ec2117b0e55cb7f60d90c85368fb4f", null ],
    [ "clientSocket", "class_socket_server.html#a0ea2afb27d1d469605185b43fa66372b", null ],
    [ "IP", "class_socket_server.html#a3e611498c8b5d6bcda1bae078bb7d6ee", null ],
    [ "port", "class_socket_server.html#ac8235a9a5efdd088f566acfae7f59826", null ],
    [ "serverAddress", "class_socket_server.html#a8bb3dddcfb0fde57a00df738630c8412", null ],
    [ "serverSocket", "class_socket_server.html#a0aa7519d25ce102a363b4492f27e7d68", null ]
];