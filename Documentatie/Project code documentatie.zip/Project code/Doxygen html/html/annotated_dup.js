var annotated_dup =
[
    [ "Deur", "class_deur.html", "class_deur" ],
    [ "Draaideur", "class_draaideur.html", "class_draaideur" ],
    [ "I2CConnection", "class_i2_c_connection.html", "class_i2_c_connection" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "QTSocketClient", "class_q_t_socket_client.html", "class_q_t_socket_client" ],
    [ "QTSocketServer", "class_q_t_socket_server.html", "class_q_t_socket_server" ],
    [ "Schuifdeur", "class_schuifdeur.html", "class_schuifdeur" ],
    [ "SocketClient", "class_socket_client.html", "class_socket_client" ],
    [ "SocketServer", "class_socket_server.html", "class_socket_server" ]
];