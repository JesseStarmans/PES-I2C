var main_c_o2_8c =
[
    [ "MAX_DUTY_CYCLE", "main_c_o2_8c.html#a9abf760e232f9c52ed7ca5cfba8b2ec5", null ],
    [ "MIN_DUTY_CYCLE", "main_c_o2_8c.html#a320185cd7e6bf74fbc3d52b7ff4a83d2", null ],
    [ "sensorAddress", "main_c_o2_8c.html#ab3fbf2ec9bab7efcf595c41395c61360", null ],
    [ "buzzer_aan", "main_c_o2_8c.html#ae4fdf2a87328613961ed8f67ed0258d0", null ],
    [ "Error_Handler", "main_c_o2_8c.html#a1730ffe1e560465665eb47d9264826f9", null ],
    [ "HAL_TIM_PeriodElapsedCallback", "main_c_o2_8c.html#a8a3b0ad512a6e6c6157440b68d395eac", null ],
    [ "main", "main_c_o2_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "SystemClock_Config", "main_c_o2_8c.html#a70af21c671abfcc773614a9a4f63d920", null ],
    [ "beweging", "main_c_o2_8c.html#a7a55cf355d6683eafdd25aceab84d036", null ],
    [ "hi2c3", "main_c_o2_8c.html#a5ccf4a01a8d7f08d3190181f843f7515", null ],
    [ "htim1", "main_c_o2_8c.html#a25fc663547539bc49fecc0011bd76ab5", null ],
    [ "htim16", "main_c_o2_8c.html#af0bea8d8759a0d7e0e296edc9f5d6936", null ],
    [ "htim2", "main_c_o2_8c.html#a2c80fd5510e2990a59a5c90d745c716c", null ],
    [ "huart2", "main_c_o2_8c.html#aa9479c261d65eecedd3d9582f7f0f89c", null ],
    [ "lastButtonPressTime", "main_c_o2_8c.html#a4d7c964dc6845ae83da6263cb4e5c06a", null ]
];