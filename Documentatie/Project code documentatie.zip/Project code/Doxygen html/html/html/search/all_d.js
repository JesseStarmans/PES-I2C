var searchData=
[
  ['raspberry_20pi_20main_0',['Raspberry Pi main',['../sub_main_page1.html',1,'I2C Raspberry Pi main'],['../sub_main_page2.html',1,'Wemos/beheerders-interface Raspberry Pi main']]],
  ['readyread_1',['readyRead',['../class_q_t_socket_client.html#aaaa7bf312fe234a789e58b793f7f8b96',1,'QTSocketClient::readyRead()'],['../class_q_t_socket_server.html#a611be0f1553760498dbd689ca092d303',1,'QTSocketServer::readyRead()']]],
  ['receive6overi2c_2',['receive6OverI2C',['../class_i2_c_connection.html#a8519fa1d44eab26b8802002f55a94918',1,'I2CConnection']]],
  ['receivedata_3',['receiveData',['../class_socket_client.html#af25b1d5653b1bf8e4ee7fd03d8f9aa8c',1,'SocketClient::receiveData()'],['../class_socket_server.html#ab5ea735b43721aad6c62dce0d9ea3545',1,'SocketServer::receiveData()']]],
  ['receiverequest_4',['receiveRequest',['../class_wemos_server.html#ab9853b575997153e96f829f3041e7d59',1,'WemosServer']]],
  ['rechtsom_5',['rechtsom',['../class_draaideur.html#a5c04815b6449c570954264b8d294f689',1,'Draaideur']]],
  ['rxcount_6',['rxcount',['../_i2_c___slave_8c.html#afa44b334b39ecda76ec3cb469d463f1a',1,'I2C_Slave.c']]],
  ['rxdata_7',['RxData',['../_i2_c___slave_8c.html#acda895c69a4afd666675b4015109fe5f',1,'I2C_Slave.c']]],
  ['rxsize_8',['RXSIZE',['../_i2_c___slave_8c.html#aff44ec68487ba91e69b2a0d54d5461aa',1,'I2C_Slave.c']]]
];
