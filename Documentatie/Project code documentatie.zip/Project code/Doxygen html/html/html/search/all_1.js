var searchData=
[
  ['checkforconnection_0',['checkForConnection',['../class_wemos_server.html#a0646d1ef39dcb3266d67550ff8116c73',1,'WemosServer']]],
  ['checkreceived_1',['checkReceived',['../class_q_t_socket_server.html#a93fd55eda228df480fbc48084751a25a',1,'QTSocketServer::checkReceived()'],['../_i2_c_test_8cpp.html#a201f1f6d0f34971358d9b3c48715f6d8',1,'checkReceived(std::string received):&#160;I2CTest.cpp'],['../_q_t_test_8cpp.html#a201f1f6d0f34971358d9b3c48715f6d8',1,'checkReceived(std::string received):&#160;QTTest.cpp']]],
  ['client_2',['client',['../class_main_window.html#a1901d65f8600d4ffc1650bbfb6efadbd',1,'MainWindow::client'],['../class_wemos_server.html#ae8ada3a0723c084072366bfda17761dd',1,'WemosServer::client'],['../_eigen_wemos_klasse_8ino.html#a7e7c1f8fd33b70e71d7a02da8af0f4e0',1,'client:&#160;EigenWemosKlasse.ino']]],
  ['clients_3',['clients',['../class_q_t_socket_server.html#a68714fd185975a94a065975477874d7a',1,'QTSocketServer']]],
  ['clientsocket_4',['clientSocket',['../class_socket_client.html#a8d434a7e2cef4ad18da1694b1135826e',1,'SocketClient::clientSocket'],['../class_socket_server.html#a0ea2afb27d1d469605185b43fa66372b',1,'SocketServer::clientSocket']]],
  ['closeclientconnection_5',['closeClientConnection',['../class_socket_server.html#a08444127be013b095c6229f5cb8124d6',1,'SocketServer']]],
  ['co2_20brand_20sensor_6',['CO2/Brand sensor',['../sub_main_page4.html#sectionMicrocontroller3',1,'']]],
  ['code_7',['code',['../sub_main_page1.html#sectionI2C3',1,'Main code'],['../sub_main_page3.html#sectionUI3',1,'Main code'],['../sub_main_page2.html#sectionWemos3',1,'Main code'],['../sub_main_page5.html#sectionWemosSocket3',1,'Main code'],['../sub_main_page4.html',1,'Microcontroller code']]],
  ['command_8',['command',['../_i2_c_test_8cpp.html#a0510afa4a991963311f592fadf4e1853',1,'I2CTest.cpp']]],
  ['connect_9',['connect',['../class_wemos_client.html#ae12764f24a1915cbccb65810e640515a',1,'WemosClient']]],
  ['connected_10',['connected',['../class_q_t_socket_client.html#aec5bbc00f8149675547806c919a357e9',1,'QTSocketClient']]],
  ['connecttoserver_11',['connectToServer',['../class_q_t_socket_client.html#a484645e1b8baa84be142fffa28ba7011',1,'QTSocketClient']]],
  ['coordinaten_12',['coordinaten',['../class_deur.html#a1e5482ed9b37455f142efd3a0185c04b',1,'Deur']]],
  ['countaddr_13',['countAddr',['../_i2_c___slave_8c.html#a45f76546f8a9e43e4ae9c8c6a5d4036a',1,'I2C_Slave.c']]],
  ['counterror_14',['counterror',['../_i2_c___slave_8c.html#a22239e80962e70c0bc368bb40de4ef96',1,'I2C_Slave.c']]]
];
