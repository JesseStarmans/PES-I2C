var searchData=
[
  ['beheerders_20interface_2fsocketclient_2ecpp_0',['socketclient.cpp',['../_beheerders_01interface_2socketclient_8cpp.html',1,'']]],
  ['beheerders_20interface_2fsocketclient_2eh_1',['socketclient.h',['../_beheerders_01interface_2socketclient_8h.html',1,'']]],
  ['beheerders_20interface_2fsocketserver_2ecpp_2',['socketserver.cpp',['../_beheerders_01interface_2socketserver_8cpp.html',1,'']]],
  ['beheerders_20interface_2fsocketserver_2eh_3',['socketserver.h',['../_beheerders_01interface_2socketserver_8h.html',1,'']]]
];
