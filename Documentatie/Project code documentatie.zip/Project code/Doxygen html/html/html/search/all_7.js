var searchData=
[
  ['klasses_0',['Klasses',['../sub_main_page1.html#sectionI2C2',1,'Klasses'],['../sub_main_page3.html#sectionUI2',1,'Klasses'],['../sub_main_page2.html#sectionWemos2',1,'Klasses'],['../sub_main_page5.html#sectionWemosSocket2',1,'Klasses']]],
  ['klasses_20includen_1',['De klasses includen',['../sub_main_page5.html#subsectionWemosSocket1Library',1,'']]]
];
