var searchData=
[
  ['i2c_20raspberry_20pi_20main_0',['I2C Raspberry Pi main',['../sub_main_page1.html',1,'']]],
  ['i2c_5fregisters_1',['I2C_REGISTERS',['../_i2_c___slave_8c.html#a4412dcf8a85da4fd491a570ca2e5b002',1,'I2C_Slave.c']]],
  ['i2c_5fslave_2',['I2C_Slave',['../sub_main_page4.html#sectionMicrocontroller2',1,'']]],
  ['i2c_5fslave_2ec_3',['I2C_Slave.c',['../_i2_c___slave_8c.html',1,'']]],
  ['i2c_5fslave_2eh_4',['I2C_Slave.h',['../_i2_c___slave_8h.html',1,'']]],
  ['i2cconnection_5',['I2CConnection',['../class_i2_c_connection.html',1,'I2CConnection'],['../class_i2_c_connection.html#ae3f7ea86b17dab88ebf79d65129504f7',1,'I2CConnection::I2CConnection()']]],
  ['i2cconnection_2ecpp_6',['I2CConnection.cpp',['../_i2_c_connection_8cpp.html',1,'']]],
  ['i2cconnection_2eh_7',['I2CConnection.h',['../_i2_c_connection_8h.html',1,'']]],
  ['i2ctest_2ecpp_8',['I2CTest.cpp',['../_i2_c_test_8cpp.html',1,'']]],
  ['includen_9',['De klasses includen',['../sub_main_page5.html#subsectionWemosSocket1Library',1,'']]],
  ['inleiding_10',['Inleiding',['../sub_main_page1.html#sectionI2C1',1,'Inleiding'],['../sub_main_page4.html#sectionMicrocontroller1',1,'Inleiding'],['../sub_main_page3.html#sectionUI1',1,'Inleiding'],['../sub_main_page2.html#sectionWemos1',1,'Inleiding'],['../sub_main_page5.html#sectionWemosSocket1',1,'Inleiding']]],
  ['interface_20main_11',['Beheerders-interface main',['../sub_main_page3.html',1,'']]],
  ['interface_20raspberry_20pi_20main_12',['Wemos/beheerders-interface Raspberry Pi main',['../sub_main_page2.html',1,'']]],
  ['ip_13',['IP',['../class_q_t_socket_client.html#ad8084468692ffe6e92eebf6e63603faa',1,'QTSocketClient::IP'],['../class_q_t_socket_server.html#a05972511bba41d56a996ce935cb172aa',1,'QTSocketServer::IP'],['../class_socket_client.html#a34df7b11ee232976977d1849fdafe270',1,'SocketClient::IP'],['../class_socket_server.html#a3e611498c8b5d6bcda1bae078bb7d6ee',1,'SocketServer::IP'],['../class_wemos_client.html#aa3222a9827a145cc334016ceb258d075',1,'WemosClient::IP']]],
  ['ipswemos_14',['IPsWemos',['../_q_t_test_8cpp.html#a04cf8cf6cea99b1e14ce940b1292e4c1',1,'QTTest.cpp']]],
  ['isdeuropen_15',['isDeurOpen',['../class_deur.html#a2cd651506f74e8678ee2ccdb9b37443f',1,'Deur']]]
];
