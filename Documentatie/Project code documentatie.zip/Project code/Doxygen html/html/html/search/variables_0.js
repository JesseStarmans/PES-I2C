var searchData=
[
  ['beweging_0',['beweging',['../main_c_o2_8c.html#a7a55cf355d6683eafdd25aceab84d036',1,'mainCO2.c']]],
  ['buttons_1',['buttons',['../class_main_window.html#a16604db51f6058d287f943bd3b2eb64c',1,'MainWindow']]]
];
