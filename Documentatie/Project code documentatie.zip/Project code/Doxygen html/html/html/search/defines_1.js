var searchData=
[
  ['geactiveerd_0',['GEACTIVEERD',['../defines_8h.html#afdd92372c65e9b224e30158f15fd00bb',1,'defines.h']]],
  ['gedeactiveerd_1',['GEDEACTIVEERD',['../defines_8h.html#a146ebfb275fc2acd97e7650204111435',1,'defines.h']]]
];
