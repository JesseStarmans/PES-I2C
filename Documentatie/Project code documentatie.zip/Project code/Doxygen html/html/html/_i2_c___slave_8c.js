var _i2_c___slave_8c =
[
    [ "RXSIZE", "_i2_c___slave_8c.html#aff44ec68487ba91e69b2a0d54d5461aa", null ],
    [ "HAL_I2C_AddrCallback", "_i2_c___slave_8c.html#a3b2a6a0ff585d8e529a73ba7d291c92d", null ],
    [ "HAL_I2C_ErrorCallback", "_i2_c___slave_8c.html#a4d5338cd64a656dfdc4154773bc4f05d", null ],
    [ "HAL_I2C_ListenCpltCallback", "_i2_c___slave_8c.html#a22544d1e6a14392cd5fe41e4e4f4cc96", null ],
    [ "HAL_I2C_SlaveRxCpltCallback", "_i2_c___slave_8c.html#ae23a5b1ce68867c35093ff2b5931e9a0", null ],
    [ "HAL_I2C_SlaveTxCpltCallback", "_i2_c___slave_8c.html#a7e086b3ee67187ea072aec6fb4d52aad", null ],
    [ "process_data", "_i2_c___slave_8c.html#ae856cc77f5b58f0ea74798069ae870a4", null ],
    [ "countAddr", "_i2_c___slave_8c.html#a45f76546f8a9e43e4ae9c8c6a5d4036a", null ],
    [ "counterror", "_i2_c___slave_8c.html#a22239e80962e70c0bc368bb40de4ef96", null ],
    [ "hi2c1", "_i2_c___slave_8c.html#af7b2c26e44dadaaa798a5c3d82914ba7", null ],
    [ "I2C_REGISTERS", "_i2_c___slave_8c.html#a4412dcf8a85da4fd491a570ca2e5b002", null ],
    [ "rxcount", "_i2_c___slave_8c.html#afa44b334b39ecda76ec3cb469d463f1a", null ],
    [ "RxData", "_i2_c___slave_8c.html#acda895c69a4afd666675b4015109fe5f", null ],
    [ "startPosition", "_i2_c___slave_8c.html#a6371e989c63e1061cb19adea134aff3d", null ],
    [ "txcount", "_i2_c___slave_8c.html#a630f9859f4a3d06136dfda2f47b516e0", null ]
];