var hierarchy =
[
    [ "Deur", "class_deur.html", [
      [ "Draaideur", "class_draaideur.html", null ],
      [ "Schuifdeur", "class_schuifdeur.html", null ]
    ] ],
    [ "I2CConnection", "class_i2_c_connection.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "QTSocketClient", "class_q_t_socket_client.html", null ]
    ] ],
    [ "QTcpServer", null, [
      [ "QTSocketServer", "class_q_t_socket_server.html", null ]
    ] ],
    [ "SocketClient", "class_socket_client.html", null ],
    [ "SocketServer", "class_socket_server.html", null ],
    [ "WiFiClient", null, [
      [ "WemosClient", "class_wemos_client.html", null ]
    ] ],
    [ "WiFiServer", null, [
      [ "WemosServer", "class_wemos_server.html", null ]
    ] ]
];