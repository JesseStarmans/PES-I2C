var searchData=
[
  ['klasses_0',['Klasses',['../sub_main_page1.html#sectionI2C2',1,'Klasses'],['../sub_main_page3.html#sectionUI2',1,'Klasses'],['../sub_main_page2.html#sectionWemos2',1,'Klasses']]]
];
