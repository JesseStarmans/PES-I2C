var searchData=
[
  ['server_0',['server',['../class_main_window.html#ad24273438867ce508267999a2784417d',1,'MainWindow']]],
  ['serveraddress_1',['serverAddress',['../class_socket_client.html#a4e6de0db93d9d424b07faeb223536630',1,'SocketClient::serverAddress'],['../class_socket_server.html#a8bb3dddcfb0fde57a00df738630c8412',1,'SocketServer::serverAddress']]],
  ['serversocket_2',['serverSocket',['../class_socket_server.html#a0aa7519d25ce102a363b4492f27e7d68',1,'SocketServer']]],
  ['slaveaddress_3',['slaveAddress',['../class_i2_c_connection.html#af29fa3a1b9e65e6c248db045c72188d7',1,'I2CConnection']]],
  ['slaveopen_4',['slaveOpen',['../class_i2_c_connection.html#a63d16f67cfb407dad553bc6447484e13',1,'I2CConnection']]],
  ['socket_5',['socket',['../class_q_t_socket_client.html#ac04aae430f4e3415eaab836e934e787f',1,'QTSocketClient']]],
  ['status_6',['status',['../class_deur.html#a6ee2a29972f8886d7c782a38165bada9',1,'Deur::status'],['../class_q_t_socket_client.html#ae6db0783590acac4261044719805159c',1,'QTSocketClient::status']]]
];
