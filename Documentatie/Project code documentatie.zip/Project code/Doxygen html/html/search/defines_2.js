var searchData=
[
  ['my_5fip_0',['MY_IP',['../_q_t_test_8cpp.html#ad9d15cbd5b02e0e6765bcf511743d680',1,'QTTest.cpp']]],
  ['my_5fport_1',['MY_PORT',['../_q_t_test_8cpp.html#a719a4dddb57833b7ec551b888419d85e',1,'QTTest.cpp']]]
];
