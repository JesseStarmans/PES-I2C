var searchData=
[
  ['client_0',['client',['../class_main_window.html#a1901d65f8600d4ffc1650bbfb6efadbd',1,'MainWindow']]],
  ['clients_1',['clients',['../class_q_t_socket_server.html#a68714fd185975a94a065975477874d7a',1,'QTSocketServer']]],
  ['clientsocket_2',['clientSocket',['../class_socket_client.html#a8d434a7e2cef4ad18da1694b1135826e',1,'SocketClient::clientSocket'],['../class_socket_server.html#a0ea2afb27d1d469605185b43fa66372b',1,'SocketServer::clientSocket']]],
  ['command_3',['command',['../_i2_c_test_8cpp.html#a0510afa4a991963311f592fadf4e1853',1,'I2CTest.cpp']]]
];
