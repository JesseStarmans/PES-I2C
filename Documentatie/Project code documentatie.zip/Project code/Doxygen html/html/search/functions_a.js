var searchData=
[
  ['schuifdeur_0',['Schuifdeur',['../class_schuifdeur.html#a55367114b1c1585e38c3468cc4e3bc5b',1,'Schuifdeur']]],
  ['senddata_1',['sendData',['../class_socket_client.html#a8909a16e2465fcedf3e38ed29f09f7b3',1,'SocketClient::sendData()'],['../class_socket_server.html#a5f49b9a12fd499fde0cc68f6f4ef256f',1,'SocketServer::sendData()']]],
  ['sendi2cto_2',['sendI2CTo',['../class_i2_c_connection.html#a31a813ec5115448f6086667e8ecc30ad',1,'I2CConnection']]],
  ['sendmessage_3',['sendMessage',['../class_q_t_socket_client.html#ab25360a530451e2cc9abe612cccbf18b',1,'QTSocketClient']]],
  ['sendmessagetoclients_4',['sendMessageToClients',['../class_q_t_socket_server.html#a01d7c4501d3409884659fd6e32096def',1,'QTSocketServer']]],
  ['sendtotemp_5',['sendToTemp',['../_i2_c_test_8cpp.html#a39a2687b8d2309ef569145d87e1c653f',1,'I2CTest.cpp']]],
  ['serveraccept_6',['serverAccept',['../class_socket_server.html#a58362554d3c65ed2ca71e65651ed0a53',1,'SocketServer']]],
  ['serverlisten_7',['serverListen',['../class_socket_server.html#ab742c7e5d268cbc174fb6af0f3fe63df',1,'SocketServer']]],
  ['setupwemosip_8',['setupWemosIP',['../class_socket_server.html#ad8ec2117b0e55cb7f60d90c85368fb4f',1,'SocketServer']]],
  ['sluit_9',['sluit',['../class_deur.html#a5a15f1848aee6ff7f65e096646baad4f',1,'Deur']]],
  ['socketclient_10',['SocketClient',['../class_socket_client.html#a4dffba6cbd7490bd9f196cd6c0800ada',1,'SocketClient']]],
  ['socketserver_11',['SocketServer',['../class_socket_server.html#a4f50740e8f8ae399c1cd22c3e688ffc2',1,'SocketServer']]],
  ['startserver_12',['startServer',['../class_q_t_socket_server.html#a91a1631859c70d9a2030f1bd4a4bf882',1,'QTSocketServer']]],
  ['stopserver_13',['stopServer',['../class_q_t_socket_server.html#a91a234e3c2ca971e2776dabe1386fe19',1,'QTSocketServer']]]
];
