var searchData=
[
  ['beheerders_20interface_20main_0',['Beheerders-interface main',['../sub_main_page3.html',1,'']]],
  ['beheerders_20interface_20raspberry_20pi_20main_1',['Wemos/beheerders-interface Raspberry Pi main',['../sub_main_page2.html',1,'']]],
  ['beheerders_20interface_2fsocketclient_2ecpp_2',['socketclient.cpp',['../_beheerders_01interface_2socketclient_8cpp.html',1,'']]],
  ['beheerders_20interface_2fsocketclient_2eh_3',['socketclient.h',['../_beheerders_01interface_2socketclient_8h.html',1,'']]],
  ['beheerders_20interface_2fsocketserver_2ecpp_4',['socketserver.cpp',['../_beheerders_01interface_2socketserver_8cpp.html',1,'']]],
  ['beheerders_20interface_2fsocketserver_2eh_5',['socketserver.h',['../_beheerders_01interface_2socketserver_8h.html',1,'']]],
  ['builden_6',['builden',['../sub_main_page1.html#subsectionI2C1Builden',1,'Het programma builden'],['../sub_main_page3.html#subsectionUI1Builden',1,'Het programma builden'],['../sub_main_page2.html#subsectionWemos1Builden',1,'Het programma builden']]],
  ['buttons_7',['buttons',['../class_main_window.html#a16604db51f6058d287f943bd3b2eb64c',1,'MainWindow']]]
];
