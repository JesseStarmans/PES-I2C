var searchData=
[
  ['main_0',['main',['../sub_main_page3.html',1,'Beheerders-interface main'],['../sub_main_page1.html',1,'I2C Raspberry Pi main'],['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.cpp'],['../_i2_c_test_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;I2CTest.cpp'],['../_q_t_test_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;QTTest.cpp'],['../sub_main_page2.html',1,'Wemos/beheerders-interface Raspberry Pi main']]],
  ['main_20code_1',['Main code',['../sub_main_page1.html#sectionI2C3',1,'Main code'],['../sub_main_page3.html#sectionUI3',1,'Main code'],['../sub_main_page2.html#sectionWemos3',1,'Main code']]],
  ['main_2ecpp_2',['main.cpp',['../main_8cpp.html',1,'']]],
  ['mainpage_2emd_3',['Mainpage.md',['../_mainpage_8md.html',1,'']]],
  ['mainwindow_4',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2ecpp_5',['mainwindow.cpp',['../mainwindow_8cpp.html',1,'']]],
  ['mainwindow_2eh_6',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['my_5fip_7',['MY_IP',['../_q_t_test_8cpp.html#ad9d15cbd5b02e0e6765bcf511743d680',1,'QTTest.cpp']]],
  ['my_5fport_8',['MY_PORT',['../_q_t_test_8cpp.html#a719a4dddb57833b7ec551b888419d85e',1,'QTTest.cpp']]]
];
