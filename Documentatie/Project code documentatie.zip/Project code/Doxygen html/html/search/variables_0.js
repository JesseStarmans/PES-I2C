var searchData=
[
  ['buttons_0',['buttons',['../class_main_window.html#a16604db51f6058d287f943bd3b2eb64c',1,'MainWindow']]]
];
