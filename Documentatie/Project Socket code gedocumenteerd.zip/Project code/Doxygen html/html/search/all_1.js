var searchData=
[
  ['checkreceived_0',['checkReceived',['../class_q_t_socket_server.html#a93fd55eda228df480fbc48084751a25a',1,'QTSocketServer::checkReceived()'],['../_i2_c_test_8cpp.html#a201f1f6d0f34971358d9b3c48715f6d8',1,'checkReceived(std::string received):&#160;I2CTest.cpp'],['../_q_t_test_8cpp.html#a201f1f6d0f34971358d9b3c48715f6d8',1,'checkReceived(std::string received):&#160;QTTest.cpp']]],
  ['client_1',['client',['../class_main_window.html#a1901d65f8600d4ffc1650bbfb6efadbd',1,'MainWindow']]],
  ['clients_2',['clients',['../class_q_t_socket_server.html#a68714fd185975a94a065975477874d7a',1,'QTSocketServer']]],
  ['clientsocket_3',['clientSocket',['../class_socket_client.html#a8d434a7e2cef4ad18da1694b1135826e',1,'SocketClient::clientSocket'],['../class_socket_server.html#a0ea2afb27d1d469605185b43fa66372b',1,'SocketServer::clientSocket']]],
  ['closeclientconnection_4',['closeClientConnection',['../class_socket_server.html#a08444127be013b095c6229f5cb8124d6',1,'SocketServer']]],
  ['code_5',['code',['../sub_main_page1.html#sectionI2C3',1,'Main code'],['../sub_main_page3.html#sectionUI3',1,'Main code'],['../sub_main_page2.html#sectionWemos3',1,'Main code']]],
  ['command_6',['command',['../_i2_c_test_8cpp.html#a0510afa4a991963311f592fadf4e1853',1,'I2CTest.cpp']]],
  ['connected_7',['connected',['../class_q_t_socket_client.html#aec5bbc00f8149675547806c919a357e9',1,'QTSocketClient']]],
  ['connecttoserver_8',['connectToServer',['../class_q_t_socket_client.html#a484645e1b8baa84be142fffa28ba7011',1,'QTSocketClient']]],
  ['coordinaten_9',['coordinaten',['../class_deur.html#a1e5482ed9b37455f142efd3a0185c04b',1,'Deur']]]
];
