var searchData=
[
  ['y_5fcoordinaat_0',['y_coordinaat',['../class_deur.html#a4e02e3283cfdb0fcb1a1baadeade167c',1,'Deur']]]
];
