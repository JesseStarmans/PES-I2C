var searchData=
[
  ['poort_0',['poort',['../class_q_t_socket_client.html#a66e310ead17d67edab259848cd2f0069',1,'QTSocketClient::poort'],['../class_q_t_socket_server.html#a4318e9291549b46ef9e96241034edd58',1,'QTSocketServer::poort']]],
  ['port_1',['port',['../class_socket_client.html#a7b6c5c88ff784969d0d31cce5d949b5d',1,'SocketClient::port'],['../class_socket_server.html#ac8235a9a5efdd088f566acfae7f59826',1,'SocketServer::port']]]
];
