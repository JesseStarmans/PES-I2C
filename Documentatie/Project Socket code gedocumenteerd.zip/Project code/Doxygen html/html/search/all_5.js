var searchData=
[
  ['i2c_20raspberry_20pi_20main_0',['I2C Raspberry Pi main',['../sub_main_page1.html',1,'']]],
  ['i2cconnection_1',['I2CConnection',['../class_i2_c_connection.html',1,'I2CConnection'],['../class_i2_c_connection.html#ae3f7ea86b17dab88ebf79d65129504f7',1,'I2CConnection::I2CConnection()']]],
  ['i2cconnection_2ecpp_2',['I2CConnection.cpp',['../_i2_c_connection_8cpp.html',1,'']]],
  ['i2cconnection_2eh_3',['I2CConnection.h',['../_i2_c_connection_8h.html',1,'']]],
  ['i2ctest_2ecpp_4',['I2CTest.cpp',['../_i2_c_test_8cpp.html',1,'']]],
  ['inleiding_5',['Inleiding',['../sub_main_page1.html#sectionI2C1',1,'Inleiding'],['../sub_main_page3.html#sectionUI1',1,'Inleiding'],['../sub_main_page2.html#sectionWemos1',1,'Inleiding']]],
  ['interface_20main_6',['Beheerders-interface main',['../sub_main_page3.html',1,'']]],
  ['interface_20raspberry_20pi_20main_7',['Wemos/beheerders-interface Raspberry Pi main',['../sub_main_page2.html',1,'']]],
  ['ip_8',['IP',['../class_q_t_socket_client.html#ad8084468692ffe6e92eebf6e63603faa',1,'QTSocketClient::IP'],['../class_q_t_socket_server.html#a05972511bba41d56a996ce935cb172aa',1,'QTSocketServer::IP'],['../class_socket_client.html#a34df7b11ee232976977d1849fdafe270',1,'SocketClient::IP'],['../class_socket_server.html#a3e611498c8b5d6bcda1bae078bb7d6ee',1,'SocketServer::IP']]],
  ['ipswemos_9',['IPsWemos',['../_q_t_test_8cpp.html#a04cf8cf6cea99b1e14ce940b1292e4c1',1,'QTTest.cpp']]],
  ['isdeuropen_10',['isDeurOpen',['../class_deur.html#a2cd651506f74e8678ee2ccdb9b37443f',1,'Deur']]]
];
