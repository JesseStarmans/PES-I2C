var searchData=
[
  ['getstatus_0',['getStatus',['../class_q_t_socket_client.html#ac8ee2fca3baf136be07f201ed7cdd2b5',1,'QTSocketClient']]]
];
