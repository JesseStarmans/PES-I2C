var searchData=
[
  ['main_0',['main',['../sub_main_page3.html',1,'Beheerders-interface main'],['../sub_main_page1.html',1,'I2C Raspberry Pi main'],['../sub_main_page2.html',1,'Wemos/beheerders-interface Raspberry Pi main']]]
];
