var files_dup =
[
    [ "Beheerders interface", "dir_5bcbd925b07fd2ef57309ee9fd04fcaf.html", "dir_5bcbd925b07fd2ef57309ee9fd04fcaf" ],
    [ "Doxygen mainpage", "dir_e1183e8f717d7a15c70dfeb9f5b61ade.html", null ],
    [ "I2C Pi", "dir_95d1d0b4e9f9cce0d9b010d05c5b1111.html", "dir_95d1d0b4e9f9cce0d9b010d05c5b1111" ],
    [ "Socket code Pi's", "dir_e7c9bcd41c86b19d4de5f848cb896aef.html", "dir_e7c9bcd41c86b19d4de5f848cb896aef" ],
    [ "Wemos Pi", "dir_c1b4b6811ed621c4515e3661a6ae4044.html", "dir_c1b4b6811ed621c4515e3661a6ae4044" ]
];