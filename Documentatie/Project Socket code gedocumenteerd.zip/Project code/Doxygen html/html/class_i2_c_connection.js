var class_i2_c_connection =
[
    [ "I2CConnection", "class_i2_c_connection.html#ae3f7ea86b17dab88ebf79d65129504f7", null ],
    [ "~I2CConnection", "class_i2_c_connection.html#acef532c78dcec950a15b17f03c3397b1", null ],
    [ "receive6OverI2C", "class_i2_c_connection.html#a8519fa1d44eab26b8802002f55a94918", null ],
    [ "sendI2CTo", "class_i2_c_connection.html#a31a813ec5115448f6086667e8ecc30ad", null ],
    [ "slaveAddress", "class_i2_c_connection.html#af29fa3a1b9e65e6c248db045c72188d7", null ],
    [ "slaveOpen", "class_i2_c_connection.html#a63d16f67cfb407dad553bc6447484e13", null ]
];