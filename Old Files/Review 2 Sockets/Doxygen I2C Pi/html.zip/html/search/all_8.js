var searchData=
[
  ['senddata_0',['sendData',['../class_socket_client.html#a8909a16e2465fcedf3e38ed29f09f7b3',1,'SocketClient::sendData()'],['../class_socket_server.html#a5f49b9a12fd499fde0cc68f6f4ef256f',1,'SocketServer::sendData()']]],
  ['sendi2cto_1',['sendI2CTo',['../class_i2_c_connection.html#a31a813ec5115448f6086667e8ecc30ad',1,'I2CConnection']]],
  ['sendtotemp_2',['sendToTemp',['../_i2_c_test_8cpp.html#a39a2687b8d2309ef569145d87e1c653f',1,'I2CTest.cpp']]],
  ['serveraccept_3',['serverAccept',['../class_socket_server.html#a58362554d3c65ed2ca71e65651ed0a53',1,'SocketServer']]],
  ['serverlisten_4',['serverListen',['../class_socket_server.html#ab742c7e5d268cbc174fb6af0f3fe63df',1,'SocketServer']]],
  ['setupwemosip_5',['setupWemosIP',['../class_socket_server.html#ad8ec2117b0e55cb7f60d90c85368fb4f',1,'SocketServer']]],
  ['socketclient_6',['SocketClient',['../class_socket_client.html',1,'SocketClient'],['../class_socket_client.html#a4dffba6cbd7490bd9f196cd6c0800ada',1,'SocketClient::SocketClient()']]],
  ['socketclient_2ecpp_7',['SocketClient.cpp',['../_socket_client_8cpp.html',1,'']]],
  ['socketclient_2eh_8',['SocketClient.h',['../_socket_client_8h.html',1,'']]],
  ['socketserver_9',['SocketServer',['../class_socket_server.html',1,'SocketServer'],['../class_socket_server.html#a4f50740e8f8ae399c1cd22c3e688ffc2',1,'SocketServer::SocketServer()']]],
  ['socketserver_2ecpp_10',['SocketServer.cpp',['../_socket_server_8cpp.html',1,'']]],
  ['socketserver_2eh_11',['SocketServer.h',['../_socket_server_8h.html',1,'']]]
];
