var searchData=
[
  ['raspberry_20pi_20main_0',['I2C Raspberry Pi main',['../index.html',1,'']]],
  ['receive6overi2c_1',['receive6OverI2C',['../class_i2_c_connection.html#a8519fa1d44eab26b8802002f55a94918',1,'I2CConnection']]],
  ['receivedata_2',['receiveData',['../class_socket_client.html#af25b1d5653b1bf8e4ee7fd03d8f9aa8c',1,'SocketClient::receiveData()'],['../class_socket_server.html#ab5ea735b43721aad6c62dce0d9ea3545',1,'SocketServer::receiveData()']]]
];
