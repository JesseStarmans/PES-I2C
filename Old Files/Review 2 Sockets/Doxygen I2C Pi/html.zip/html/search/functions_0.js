var searchData=
[
  ['checkreceived_0',['checkReceived',['../_i2_c_test_8cpp.html#a201f1f6d0f34971358d9b3c48715f6d8',1,'I2CTest.cpp']]],
  ['closeclientconnection_1',['closeClientConnection',['../class_socket_server.html#a08444127be013b095c6229f5cb8124d6',1,'SocketServer']]]
];
