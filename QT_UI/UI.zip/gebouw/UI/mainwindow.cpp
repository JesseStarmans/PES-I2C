#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
#include <QNetworkInterface>
#include <QDebug>
#include <QPainter>
#include <iostream>
#include "draaideur.h"
#include "schuifdeur.h"
#include "defines.h"
#include "socketclient.h"
#include "socketserver.h"
#include "indicator.h"

#define MY_IP "145.52.127.204"
#define PI_A "145.52.127.184"

void MainWindow::initImage(){
    /*------------- Setup for automatisch image (plattegrond) invoer -------------*/
    QDir executableDir(QCoreApplication::applicationDirPath());
    executableDir.cdUp();
    executableDir.cdUp();
    executableDir.cdUp();
    imagePath = executableDir.filePath("Lege plattegrond appartementen.png");
    qDebug() << "Path: " << imagePath;
}

/*!
 * @brief Checkt alle internet interfaces en stuurt het WiFi IP terug
 * @return Stuurt het IP van de WiFi interface terug, of een lege string als er WiFi verbinding is.
 */
QString init(){
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();

    for(const QNetworkInterface &interface : interfaces){
        // Controleer of de interface de gewenste naam bevat
        if (interface.humanReadableName().contains("Wi-Fi", Qt::CaseInsensitive)){
            QList<QNetworkAddressEntry> entries = interface.addressEntries();
            for (const QNetworkAddressEntry &entry : entries){
                if(entry.ip().protocol() == QAbstractSocket::IPv4Protocol && !entry.ip().isLoopback()){
                    return entry.ip().toString();
                }
            }
        }
    }
    return "";
}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    resize(1300,800);

    /* Setup voor Image(plattegrond) */
    initImage();

    /* Indicatoren maken */
    indicatoren.push_back(make_shared<Indicator>(275,200,false)); // Verwarming status
    indicatoren.push_back(make_shared<Indicator>(700,175,false)); // Co2 status
    indicatoren.push_back(make_shared<Indicator>(100,25,false)); // Plant status
    indicatoren.push_back(make_shared<Indicator>(35,200,false)); // Bed status

    /*Deuren aanmaken en in een vector stoppen*/
    deuren.push_back(make_shared<Schuifdeur>(1055, 440, 210));
    deuren.push_back(make_shared<Draaideur>(223, 430, 75, false, false));
    deuren.push_back(make_shared<Draaideur>(475, 430, 75, false, true));

    /*Knoppen voor de deuren aanmaken en in een vector stoppen*/
    buttons.push_back(new QPushButton("Voordeur", this));
    buttons.push_back(new QPushButton("Deur1", this));
    buttons.push_back(new QPushButton("Deur2", this));

    /*Voordeur Knop aanmaken*/
    buttons.at(0)->setGeometry(QRect(QPoint(1065, 200), QSize(75, 25)));
    connect(buttons.at(0), &QPushButton::released, this, &MainWindow::handleVoordeur);

    /*Deur 1 Knop aanmaken*/
    buttons.at(1)->setGeometry(QRect(QPoint(230, 450), QSize(75, 25)));
    connect(buttons.at(1), &QPushButton::released, this, &MainWindow::handleDeur1);

    /*Deur 2 Knop aanmaken*/
    buttons.at(2)->setGeometry(QRect(QPoint(400, 450), QSize(75, 25)));
    connect(buttons.at(2), &QPushButton::released, this, &MainWindow::handleDeur2);

    /*lichtkrantTekst invoerveld aanmaken en plaatsen*/
    lichtkrantTekst = new QLineEdit(this);
    lichtkrantTekst->setPlaceholderText("Lichtkranttekst");
    lichtkrantTekst->setGeometry(850, 700, 120, 22);
    connect(lichtkrantTekst, &QLineEdit::returnPressed, this, &MainWindow::handleInvoerTekst);

    /*lichtkrantWeergave tekst weergave aanmaken en plaatsen*/
    lichtkrantWeergave = new QLabel(this);
    lichtkrantWeergave->setGeometry(850, 730, 120, 22);

    /* Temperatuur invoerveld aanmaken en plaatsen */
    temperatuurTekst = new QLineEdit(this);
    temperatuurTekst->setPlaceholderText("Voer STM command in: ");
    temperatuurTekst->setGeometry(1150, 700, 120, 22);
    connect(temperatuurTekst, &QLineEdit::returnPressed, this, &MainWindow::handleSTMTekst);

    /* temperatuurWeergave aanmaken en plaatsen */
    temperatuurWeergave = new QLabel(this);
    temperatuurWeergave->setGeometry(200, 310, 250, 35);

    /*Co2Weergave aanmaken en plaatsen*/
    Co2Weergave = new QLabel(this);
    Co2Weergave->setGeometry(700, 190, 250, 35);

    /*CO2 Set en Get aanmaken en plaatsen*/
    CO2Set = new QLineEdit(this);
    CO2Set->setPlaceholderText("Voer CO2 randwaarde in");
    CO2Set->setGeometry(700, 220, 100, 21);
    connect(CO2Set, &QLineEdit::returnPressed, this, &MainWindow::handleSetCO2);

    CO2Get = new QPushButton("Get CO2", this);
    CO2Get->setGeometry(700, 245, 100, 21);
    connect(CO2Get, &QPushButton::released, this, &MainWindow::handleGetCO2);

    /*Temp Set en Get aanmaken en plaatsen*/
    TempSet = new QLineEdit(this);
    TempSet->setPlaceholderText("Voer gewenste temp in");
    TempSet->setGeometry(200, 280, 100, 21);
    connect(TempSet, &QLineEdit::returnPressed, this, &MainWindow::handleSetTemp);

    TempGet = new QPushButton("Get Temp", this);
    TempGet->setGeometry(200, 250, 100, 21);
    connect(TempGet, &QPushButton::released, this, &MainWindow::handleGetTemp);

    /* Server logica */
    client = new SocketClient(PI_A, 8080);
    IP = init();
    qInfo() << IP;

    server = new SocketServer(IP, 9090);
    server->startServer();

    connect(server, &SocketServer::Voordeur, this, &MainWindow::handleSocketVoordeur);
    connect(server, &SocketServer::Deur1, this, &MainWindow::handleSocketDeur1);
    connect(server, &SocketServer::Deur2, this, &MainWindow::handleSocketDeur2);
    connect(server, &SocketServer::Temperatuur, this, &MainWindow::handleSocketTempSensor);
    connect(server, &SocketServer::Co2, this, &MainWindow::handleSocketCo2);
    connect(server, &SocketServer::Plant, this, &MainWindow::handleSocketPlant);
    connect(server, &SocketServer::Druk, this, &MainWindow::handleSocketDruk);
}

void MainWindow::paintEvent(QPaintEvent *event){

    QPainter painter(this);
    QImage image(imagePath); // Automatisch path herkenning image (zie initImage())

    painter.drawImage(10,10,image);

    for (int i = 0; i < (int)deuren.size(); i++) {
        deuren.at(i)->teken(this);
    }
    // loop over alle indicatoren
    for (auto it : indicatoren) { it->teken(this); }
}

void MainWindow::handleVoordeur() {
    client->connectToServer();
    if (deuren.at(0)->isDeurOpen() == OPEN) {
        deuren.at(0)->sluit();
        client->sendMessage("VoordeurKnop Sluiten");
    }
    else {
        deuren.at(0)->open();
        client->sendMessage("VoordeurKnop Openen");
    }
    update();
}

void MainWindow::handleDeur1() {
    client->connectToServer();
    if (deuren.at(1)->isDeurOpen() == OPEN) {
        deuren.at(1)->sluit();
        client->sendMessage("Deur1Knop Sluiten");
    }
    else {
        deuren.at(1)->open();
        client->sendMessage("Deur1Knop Openen");
    }
    update();
}

void MainWindow::handleDeur2() {
    client->connectToServer();
    if (deuren.at(2)->isDeurOpen() == OPEN) {
        deuren.at(2)->sluit();
        client->sendMessage("Deur2Knop Sluiten");
    }
    else {
        deuren.at(2)->open();
        client->sendMessage("Deur2Knop Openen");
    }
    update();
}

void MainWindow::handleInvoerTekst() {
    QString tekst = lichtkrantTekst->text().toUpper();
    lichtkrantWeergave->setText(tekst);

    client->connectToServer();
    client->sendMessage("lichtkrant: ");
    client->sendMessage(tekst);
    client->sendMessage("     ");

    lichtkrantTekst->clear();
    update();
}

void MainWindow::handleSTMTekst(){
    QString tekst = temperatuurTekst->text();

    client->connectToServer();
    client->sendMessage(tekst);

    temperatuurTekst->clear();
    update();
}
void MainWindow::handleSocketVoordeur(bool isOpen) {
    if (isOpen == OPEN) {
        deuren.at(0)->open();
    }
    else {
        deuren.at(0)->sluit();
    }
    update();
}

void MainWindow::handleSocketDeur1(bool isOpen) {
    if (isOpen == OPEN) {
        deuren.at(1)->open();
    }
    else {
        deuren.at(1)->sluit();
    }
    update();
}

void MainWindow::handleSocketDeur2(bool isOpen) {
    if (isOpen == OPEN) {
        deuren.at(2)->open();
    }
    else {
        deuren.at(2)->sluit();
    }
    update();
}

void MainWindow::handleSocketTempSensor(std::string msg){
    // hier moet dan juiste msg splitsing voor temperatuur(float), luchtvochtigheid en verwarming status
    temperatuur = stod(msg.substr(0,2));
    temperatuur += stod(msg.substr(2,3));
    luchtvochtigheid = stoi(msg.substr(5,6));
    verwarming = (SocketServer::toInt(msg.substr(8,8)) == 1 ? 1 : 0);
    QString temp = QString("Temperatuur: %1C \nLuchtvochtigheid: %2%").arg(QString::number(temperatuur),QString::number(luchtvochtigheid));
    temperatuurWeergave->setText(temp);
    indicatoren.at(0)->setStatus(verwarming);

    update();
    //qDebug() << temperatuur;
    //qDebug() << luchtvochtigheid;
}

void MainWindow::handleSocketCo2(std::string msg){
    Co2Level = stoi(msg.substr(0,3));
    if (Co2Level >= Co2Allowed) {
        Co2Alarm = 1;
    }
    else {
        Co2Alarm = 0;
    }
    QString qTemp = QString("Co2: %1").arg(Co2Level);
    std::string temp = qTemp.toStdString();
    Co2Weergave->setText(QString::fromStdString(temp));
    indicatoren.at(1)->setStatus(Co2Alarm);
    qDebug() << Co2Level;
    update();
}

void MainWindow::handleSocketPlant(std::string msg){
    indicatoren.at(2)->setStatus(stoi(msg));
}

void MainWindow::handleSocketDruk(std::string msg){
    indicatoren.at(3)->setStatus(stoi(msg));
}

void MainWindow::handleGetCO2() {
    client->connectToServer();
    client->sendMessage("Check CO2");
    update();
}

void MainWindow::handleSetCO2() {
    QString set = CO2Set->text();

    Co2Allowed = stoi(set.toStdString());

    client->connectToServer();
    client->sendMessage("204 ");
    client->sendMessage(set);

    CO2Set->clear();
    update();
}

void MainWindow::handleGetTemp() {
    client->connectToServer();
    client->sendMessage("200");
    update();
}

void MainWindow::handleSetTemp() {
    QString set = TempSet->text();

    client->connectToServer();
    client->sendMessage("201 ");
    client->sendMessage(set);

    TempSet->clear();
    update();
}

MainWindow::~MainWindow() {
    delete ui;
    for (int i = 0; i < (int)buttons.size(); i++) {
        delete(buttons.at(i));
    }
    client->disconnectFromServer();

    // Glenn: added want memoryleak (27-05)
    delete lichtkrantTekst;
    delete lichtkrantWeergave;
    delete temperatuurTekst;
    delete temperatuurWeergave;
    delete Co2Weergave;
    delete CO2Set;
    delete CO2Get;
    delete TempSet;
    delete TempGet;
    delete client;
    delete server;
}

