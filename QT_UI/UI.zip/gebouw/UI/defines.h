#ifndef DEFINES_H
#define DEFINES_H

#define OPEN true
#define DICHT false
#define GEACTIVEERD true
#define GEDEACTIVEERD false

#endif // DEFINES_H
