/*
 * I2C_Slave.h
 *
 *  Created on: Mar 26, 2024
 *      Author: Jesse
 */

#ifndef INC_I2C_SLAVE_H_
#define INC_I2C_SLAVE_H_



#endif /* INC_I2C_SLAVE_H_ */
