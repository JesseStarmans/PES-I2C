var searchData=
[
  ['socketclient_0',['SocketClient',['../class_socket_client.html',1,'']]],
  ['socketserver_1',['SocketServer',['../class_socket_server.html',1,'']]]
];
