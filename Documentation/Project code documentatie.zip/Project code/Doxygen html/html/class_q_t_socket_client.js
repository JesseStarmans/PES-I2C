var class_q_t_socket_client =
[
    [ "QTSocketClient", "class_q_t_socket_client.html#a75c3c461080bc7a1ed0d985f98b55f24", null ],
    [ "~QTSocketClient", "class_q_t_socket_client.html#af44bd1e1196e9d3680ae7b39c3087bdc", null ],
    [ "connected", "class_q_t_socket_client.html#aec5bbc00f8149675547806c919a357e9", null ],
    [ "connectToServer", "class_q_t_socket_client.html#a484645e1b8baa84be142fffa28ba7011", null ],
    [ "disconnected", "class_q_t_socket_client.html#a812817b3731f499c0b489f7965280ded", null ],
    [ "disconnectFromServer", "class_q_t_socket_client.html#a2e68de2b17b187f769c952f1288526bd", null ],
    [ "getStatus", "class_q_t_socket_client.html#ac8ee2fca3baf136be07f201ed7cdd2b5", null ],
    [ "processMessage", "class_q_t_socket_client.html#ac5584b166f6a7c709c064123dd97382c", null ],
    [ "readyRead", "class_q_t_socket_client.html#aaaa7bf312fe234a789e58b793f7f8b96", null ],
    [ "sendMessage", "class_q_t_socket_client.html#ab25360a530451e2cc9abe612cccbf18b", null ],
    [ "IP", "class_q_t_socket_client.html#ad8084468692ffe6e92eebf6e63603faa", null ],
    [ "poort", "class_q_t_socket_client.html#a66e310ead17d67edab259848cd2f0069", null ],
    [ "socket", "class_q_t_socket_client.html#ac04aae430f4e3415eaab836e934e787f", null ],
    [ "status", "class_q_t_socket_client.html#ae6db0783590acac4261044719805159c", null ]
];