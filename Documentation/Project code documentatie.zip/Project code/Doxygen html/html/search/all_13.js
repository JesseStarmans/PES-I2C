var searchData=
[
  ['x_5fcoordinaat_0',['x_coordinaat',['../class_deur.html#a54410139832df8f5f35152d2ed6a07b3',1,'Deur']]]
];
