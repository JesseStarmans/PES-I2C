var searchData=
[
  ['txcount_0',['txcount',['../_i2_c___slave_8c.html#a630f9859f4a3d06136dfda2f47b516e0',1,'I2C_Slave.c']]]
];
