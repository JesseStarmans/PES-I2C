var searchData=
[
  ['getipaddress_0',['getIPAddress',['../_eigen_wemos_klasse_8ino.html#a2ad9bbcfaa97578139874f8bc202ba0f',1,'EigenWemosKlasse.ino']]],
  ['getstatus_1',['getStatus',['../class_q_t_socket_client.html#ac8ee2fca3baf136be07f201ed7cdd2b5',1,'QTSocketClient']]]
];
