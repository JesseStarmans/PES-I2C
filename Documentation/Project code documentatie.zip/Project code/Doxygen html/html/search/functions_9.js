var searchData=
[
  ['open_0',['open',['../class_deur.html#a7a1558f174da7f27b19ffe8fc6bf2602',1,'Deur']]]
];
