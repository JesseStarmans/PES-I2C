var searchData=
[
  ['qtsocketclient_0',['QTSocketClient',['../class_q_t_socket_client.html#a75c3c461080bc7a1ed0d985f98b55f24',1,'QTSocketClient']]],
  ['qtsocketserver_1',['QTSocketServer',['../class_q_t_socket_server.html#aa70d923e4d19efd84e442bb6d4096f61',1,'QTSocketServer']]]
];
