var searchData=
[
  ['rechtsom_0',['rechtsom',['../class_draaideur.html#a5c04815b6449c570954264b8d294f689',1,'Draaideur']]],
  ['rxcount_1',['rxcount',['../_i2_c___slave_8c.html#afa44b334b39ecda76ec3cb469d463f1a',1,'I2C_Slave.c']]],
  ['rxdata_2',['RxData',['../_i2_c___slave_8c.html#acda895c69a4afd666675b4015109fe5f',1,'I2C_Slave.c']]]
];
