var searchData=
[
  ['raspberry_20pi_20main_0',['Raspberry Pi main',['../sub_main_page1.html',1,'I2C Raspberry Pi main'],['../sub_main_page2.html',1,'Wemos/beheerders-interface Raspberry Pi main']]]
];
