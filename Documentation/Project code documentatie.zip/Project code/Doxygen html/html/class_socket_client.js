var class_socket_client =
[
    [ "SocketClient", "class_socket_client.html#a4dffba6cbd7490bd9f196cd6c0800ada", null ],
    [ "~SocketClient", "class_socket_client.html#af4ecba63b08737b5be4fef324cef1df6", null ],
    [ "receiveData", "class_socket_client.html#af25b1d5653b1bf8e4ee7fd03d8f9aa8c", null ],
    [ "sendData", "class_socket_client.html#a8909a16e2465fcedf3e38ed29f09f7b3", null ],
    [ "clientSocket", "class_socket_client.html#a8d434a7e2cef4ad18da1694b1135826e", null ],
    [ "IP", "class_socket_client.html#a34df7b11ee232976977d1849fdafe270", null ],
    [ "port", "class_socket_client.html#a7b6c5c88ff784969d0d31cce5d949b5d", null ],
    [ "serverAddress", "class_socket_client.html#a4e6de0db93d9d424b07faeb223536630", null ]
];