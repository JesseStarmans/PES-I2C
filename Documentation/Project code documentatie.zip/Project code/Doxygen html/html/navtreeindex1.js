var NAVTREEINDEX1 =
{
"sub_main_page3.html#sectionUI3":[2,2],
"sub_main_page3.html#subsectionUI1Builden":[2,0,0],
"sub_main_page4.html":[1],
"sub_main_page4.html#sectionMicrocontroller1":[1,0],
"sub_main_page4.html#sectionMicrocontroller2":[1,1],
"sub_main_page4.html#sectionMicrocontroller3":[1,2],
"sub_main_page5.html":[4],
"sub_main_page5.html#sectionWemosSocket1":[4,0],
"sub_main_page5.html#sectionWemosSocket2":[4,1],
"sub_main_page5.html#sectionWemosSocket3":[4,2],
"sub_main_page5.html#subsectionWemosSocket1Library":[4,1,0]
};
