var class_wemos_client =
[
    [ "WemosClient", "class_wemos_client.html#a4700b138d65dcf7b4f0ee0f8e92a7d1a", null ],
    [ "~WemosClient", "class_wemos_client.html#abf84e9cd844be9facbbc3fc851cfa14f", null ],
    [ "connect", "class_wemos_client.html#ae12764f24a1915cbccb65810e640515a", null ],
    [ "sendInput", "class_wemos_client.html#ab6b2aec4980b44ec4998dff77bd0fa95", null ],
    [ "sendIP", "class_wemos_client.html#a2f61deb786ecd34bd9603669280cc2ce", null ],
    [ "IP", "class_wemos_client.html#aa3222a9827a145cc334016ceb258d075", null ],
    [ "port", "class_wemos_client.html#a2db22cf632b8b742f2bdd728d55cae38", null ]
];