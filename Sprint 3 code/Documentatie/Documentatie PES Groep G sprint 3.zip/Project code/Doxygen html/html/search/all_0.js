var searchData=
[
  ['adcvalue_0',['adcValue',['../main_druksensor_8c.html#a97127075abf5adcf325971fecc8ce970',1,'mainDruksensor.c']]],
  ['autohand_1',['autohand',['../main_l_d_r_6_servo_8c.html#af4c3d325dc627cae8615a300db7496cd',1,'mainLDR&amp;Servo.c']]]
];
