var searchData=
[
  ['pi_5fa_0',['PI_A',['../mainwindow_8cpp.html#aeb58e5bb7f8f2bf9f5478ae37d43dbf6',1,'mainwindow.cpp']]],
  ['pi_5fb_1',['PI_B',['../_q_t_test_8cpp.html#a6b7bd63fbb9ec0f1369dc38709bc92fd',1,'QTTest.cpp']]]
];
