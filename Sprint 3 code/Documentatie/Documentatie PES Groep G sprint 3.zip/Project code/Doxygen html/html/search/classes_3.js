var searchData=
[
  ['qtsocketclient_0',['QTSocketClient',['../class_q_t_socket_client.html',1,'']]],
  ['qtsocketserver_1',['QTSocketServer',['../class_q_t_socket_server.html',1,'']]]
];
