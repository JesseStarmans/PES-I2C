var searchData=
[
  ['main_0',['main',['../sub_main_page3.html',1,'Beheerders-interface main'],['../sub_main_page1.html',1,'I2C Raspberry Pi main'],['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.cpp'],['../_i2_c_test_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;I2CTest.cpp'],['../main_beweginssensor_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;mainBeweginssensor.c'],['../main_c_o2_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;mainCO2.c'],['../main_druksensor_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;mainDruksensor.c'],['../main_l_d_r_6_servo_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;mainLDR&amp;Servo.c'],['../_q_t_test_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;QTTest.cpp'],['../sub_main_page5.html',1,'Wemos socket main'],['../sub_main_page2.html',1,'Wemos/beheerders-interface Raspberry Pi main']]],
  ['main_20code_1',['Main code',['../sub_main_page1.html#sectionI2C3',1,'Main code'],['../sub_main_page3.html#sectionUI3',1,'Main code'],['../sub_main_page2.html#sectionWemos3',1,'Main code'],['../sub_main_page5.html#sectionWemosSocket3',1,'Main code']]],
  ['main_2ecpp_2',['main.cpp',['../main_8cpp.html',1,'']]],
  ['mainbeweginssensor_2ec_3',['mainBeweginssensor.c',['../main_beweginssensor_8c.html',1,'']]],
  ['mainco2_2ec_4',['mainCO2.c',['../main_c_o2_8c.html',1,'']]],
  ['maindruksensor_2ec_5',['mainDruksensor.c',['../main_druksensor_8c.html',1,'']]],
  ['mainldr_26servo_2ec_6',['mainLDR&amp;Servo.c',['../main_l_d_r_6_servo_8c.html',1,'']]],
  ['mainpage_2emd_7',['Mainpage.md',['../_mainpage_8md.html',1,'']]],
  ['mainwindow_8',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2ecpp_9',['mainwindow.cpp',['../mainwindow_8cpp.html',1,'']]],
  ['mainwindow_2eh_10',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['max_5fduty_5fcycle_11',['MAX_DUTY_CYCLE',['../main_c_o2_8c.html#a9abf760e232f9c52ed7ca5cfba8b2ec5',1,'mainCO2.c']]],
  ['microcontroller_20code_12',['Microcontroller code',['../sub_main_page4.html',1,'']]],
  ['min_5fduty_5fcycle_13',['MIN_DUTY_CYCLE',['../main_c_o2_8c.html#a320185cd7e6bf74fbc3d52b7ff4a83d2',1,'mainCO2.c']]],
  ['msg_14',['msg',['../main_druksensor_8c.html#a69ec70215905255b079dbcd26780c370',1,'mainDruksensor.c']]],
  ['my_5fip_15',['MY_IP',['../_q_t_test_8cpp.html#ad9d15cbd5b02e0e6765bcf511743d680',1,'QTTest.cpp']]],
  ['my_5fport_16',['MY_PORT',['../_q_t_test_8cpp.html#a719a4dddb57833b7ec551b888419d85e',1,'QTTest.cpp']]]
];
