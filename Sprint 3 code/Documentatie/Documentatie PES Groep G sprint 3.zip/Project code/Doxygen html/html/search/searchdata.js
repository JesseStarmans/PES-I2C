var indexSectionsWithContent =
{
  0: "abcdeghiklmopqrstuvwxy~",
  1: "dimqsw",
  2: "u",
  3: "bdeimpqsw",
  4: "bcdeghilmopqrstvw~",
  5: "abcdhilmprstuvxy",
  6: "dgmoprst",
  7: "bcdgimprsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros",
  7: "Pages"
};

