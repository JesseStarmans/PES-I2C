var searchData=
[
  ['debounce_5fdelay_5fms_0',['DEBOUNCE_DELAY_MS',['../main_beweginssensor_8c.html#ad9f5ab5ce9186dd30e74331b822a3317',1,'mainBeweginssensor.c']]],
  ['dicht_1',['DICHT',['../defines_8h.html#a03ca9626dec2f944520fa9920459db20',1,'defines.h']]]
];
