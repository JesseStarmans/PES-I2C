var searchData=
[
  ['y_5fcoordinaat_0',['y_coordinaat',['../class_deur.html#a4e02e3283cfdb0fcb1a1baadeade167c',1,'Deur']]],
  ['ycoordinaat_1',['yCoordinaat',['../class_indicator.html#a8f16c9364ba6ecaed506a96bec2a9881',1,'Indicator']]]
];
