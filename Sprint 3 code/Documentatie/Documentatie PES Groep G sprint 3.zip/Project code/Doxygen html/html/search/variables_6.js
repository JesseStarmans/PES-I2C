var searchData=
[
  ['lastbuttonpresstime_0',['lastButtonPressTime',['../main_beweginssensor_8c.html#a4d7c964dc6845ae83da6263cb4e5c06a',1,'lastButtonPressTime:&#160;mainBeweginssensor.c'],['../main_c_o2_8c.html#a4d7c964dc6845ae83da6263cb4e5c06a',1,'lastButtonPressTime:&#160;mainCO2.c']]],
  ['lengte_1',['lengte',['../class_deur.html#a05c55b7c086873d348bd03f6c92d9029',1,'Deur']]],
  ['lichtkranttekst_2',['lichtkrantTekst',['../class_main_window.html#a6360ebf4b39eea31d339eaa750ec65b8',1,'MainWindow']]],
  ['lichtkrantweergave_3',['lichtkrantWeergave',['../class_main_window.html#a6277bb7c550b69b3b19ac0e80ef8f2e3',1,'MainWindow']]],
  ['liggend_4',['liggend',['../class_draaideur.html#ad6cfdb6d2b6b1dee67f79bad1e06be0f',1,'Draaideur']]],
  ['luchtvochtigheid_5',['luchtvochtigheid',['../class_main_window.html#a8087d98f2b8f8f94caef51835749b1f9',1,'MainWindow']]]
];
