var searchData=
[
  ['rxsize_0',['RXSIZE',['../_i2_c___slave_8c.html#aff44ec68487ba91e69b2a0d54d5461aa',1,'I2C_Slave.c']]]
];
