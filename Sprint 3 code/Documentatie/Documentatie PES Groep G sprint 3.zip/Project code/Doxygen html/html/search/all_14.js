var searchData=
[
  ['x_5fcoordinaat_0',['x_coordinaat',['../class_deur.html#a54410139832df8f5f35152d2ed6a07b3',1,'Deur']]],
  ['xcoordinaat_1',['xCoordinaat',['../class_indicator.html#a8312df4bc011705e2bfe2ecb27fba986',1,'Indicator']]]
];
