var searchData=
[
  ['temperatuur_0',['temperatuur',['../class_main_window.html#aa0a9f2baddd6c67205d3d49557efb160',1,'MainWindow']]],
  ['temperatuurtekst_1',['temperatuurTekst',['../class_main_window.html#a1bb67ff0c00c634e6f8f83c9e57dd20d',1,'MainWindow']]],
  ['temperatuurweergave_2',['temperatuurWeergave',['../class_main_window.html#a1e740a4898b7b013cd3c863f965f1cb2',1,'MainWindow']]],
  ['txcount_3',['txcount',['../_i2_c___slave_8c.html#a630f9859f4a3d06136dfda2f47b516e0',1,'I2C_Slave.c']]]
];
