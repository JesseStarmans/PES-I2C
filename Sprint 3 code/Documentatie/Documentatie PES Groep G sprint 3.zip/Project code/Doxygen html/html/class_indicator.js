var class_indicator =
[
    [ "Indicator", "class_indicator.html#a41c0a98856ae9d6b1f452f98a1ea115e", null ],
    [ "~Indicator", "class_indicator.html#a8099ca10ae3ae131b0423899f1abb61c", null ],
    [ "setDicht", "class_indicator.html#aa8d33d43776cf2d5fec9923d990a795f", null ],
    [ "setOpen", "class_indicator.html#a3727e0723945c8e4671de969c17f8308", null ],
    [ "setStatus", "class_indicator.html#abe9ee629841adcedcc3072076697f440", null ],
    [ "teken", "class_indicator.html#aa6d02a49ab7aea122696eceabeb43c02", null ],
    [ "status", "class_indicator.html#ac551f82f0fae30231a89ed6d73560326", null ],
    [ "xCoordinaat", "class_indicator.html#a8312df4bc011705e2bfe2ecb27fba986", null ],
    [ "yCoordinaat", "class_indicator.html#a8f16c9364ba6ecaed506a96bec2a9881", null ]
];