var class_deur =
[
    [ "Deur", "class_deur.html#abf685a028212452f7bef1433dfca783c", null ],
    [ "~Deur", "class_deur.html#aa41e5cf7aa9ddb0b8253a0ce4e8f1d8e", null ],
    [ "coordinaten", "class_deur.html#a1e5482ed9b37455f142efd3a0185c04b", null ],
    [ "deurLengte", "class_deur.html#a49bb85a2202cba0e496834d52f827df9", null ],
    [ "isDeurOpen", "class_deur.html#a2cd651506f74e8678ee2ccdb9b37443f", null ],
    [ "open", "class_deur.html#a7a1558f174da7f27b19ffe8fc6bf2602", null ],
    [ "sluit", "class_deur.html#a5a15f1848aee6ff7f65e096646baad4f", null ],
    [ "teken", "class_deur.html#a43aed08defc4c82a951a600e99105a88", null ],
    [ "lengte", "class_deur.html#a05c55b7c086873d348bd03f6c92d9029", null ],
    [ "status", "class_deur.html#a6ee2a29972f8886d7c782a38165bada9", null ],
    [ "x_coordinaat", "class_deur.html#a54410139832df8f5f35152d2ed6a07b3", null ],
    [ "y_coordinaat", "class_deur.html#a4e02e3283cfdb0fcb1a1baadeade167c", null ]
];