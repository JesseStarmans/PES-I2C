var class_q_t_socket_server =
[
    [ "QTSocketServer", "class_q_t_socket_server.html#aa70d923e4d19efd84e442bb6d4096f61", null ],
    [ "~QTSocketServer", "class_q_t_socket_server.html#a2ab8651ea10535928c15f363dfa17518", null ],
    [ "checkReceived", "class_q_t_socket_server.html#a93fd55eda228df480fbc48084751a25a", null ],
    [ "Co2", "class_q_t_socket_server.html#adee74f9cccc79fc788d9c27edfcf0243", null ],
    [ "Deur1", "class_q_t_socket_server.html#aa19f4f5b4cd4fe7f6e432eadbcf4f725", null ],
    [ "Deur2", "class_q_t_socket_server.html#a87b6e770564c7496ef1e4550695acdc4", null ],
    [ "Druk", "class_q_t_socket_server.html#a6396b6d9985d7ba010729fd3df0db0ec", null ],
    [ "handleNewConnection", "class_q_t_socket_server.html#a7a731eb6d882bc012f2ae64e6d32b213", null ],
    [ "Plant", "class_q_t_socket_server.html#aa321384e92395ab56c4d50bf89743e0a", null ],
    [ "readyRead", "class_q_t_socket_server.html#a611be0f1553760498dbd689ca092d303", null ],
    [ "sendMessageToClients", "class_q_t_socket_server.html#a934e5238f3cc4762b655cffcb27182fe", null ],
    [ "startServer", "class_q_t_socket_server.html#a91a1631859c70d9a2030f1bd4a4bf882", null ],
    [ "stopServer", "class_q_t_socket_server.html#a91a234e3c2ca971e2776dabe1386fe19", null ],
    [ "Temperatuur", "class_q_t_socket_server.html#af7e385cfa226b963b348de762b77b9bb", null ],
    [ "toInt", "class_q_t_socket_server.html#a7c2ec5886c03448a025e8ee029939e7e", null ],
    [ "Voordeur", "class_q_t_socket_server.html#a7708750035df1b1ec90373995c85e490", null ],
    [ "clients", "class_q_t_socket_server.html#a68714fd185975a94a065975477874d7a", null ],
    [ "IP", "class_q_t_socket_server.html#a05972511bba41d56a996ce935cb172aa", null ],
    [ "poort", "class_q_t_socket_server.html#a4318e9291549b46ef9e96241034edd58", null ]
];