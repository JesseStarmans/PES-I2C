var dir_33f05a75383d2cec79d7229eac7d1c7e =
[
    [ "I2C_Slave.c", "_i2_c___slave_8c.html", "_i2_c___slave_8c" ],
    [ "I2C_Slave.h", "_i2_c___slave_8h.html", null ],
    [ "mainBeweginssensor.c", "main_beweginssensor_8c.html", "main_beweginssensor_8c" ],
    [ "mainCO2.c", "main_c_o2_8c.html", "main_c_o2_8c" ],
    [ "mainDruksensor.c", "main_druksensor_8c.html", "main_druksensor_8c" ],
    [ "mainLDR&Servo.c", "main_l_d_r_6_servo_8c.html", "main_l_d_r_6_servo_8c" ]
];