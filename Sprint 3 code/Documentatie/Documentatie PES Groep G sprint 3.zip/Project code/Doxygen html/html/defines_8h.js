var defines_8h =
[
    [ "DICHT", "defines_8h.html#a03ca9626dec2f944520fa9920459db20", null ],
    [ "GEACTIVEERD", "defines_8h.html#afdd92372c65e9b224e30158f15fd00bb", null ],
    [ "GEDEACTIVEERD", "defines_8h.html#a146ebfb275fc2acd97e7650204111435", null ],
    [ "OPEN", "defines_8h.html#a1354b70ac6803a06beebe84f61b5f95b", null ]
];