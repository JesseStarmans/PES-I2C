var main_beweginssensor_8c =
[
    [ "DEBOUNCE_DELAY_MS", "main_beweginssensor_8c.html#ad9f5ab5ce9186dd30e74331b822a3317", null ],
    [ "Error_Handler", "main_beweginssensor_8c.html#a1730ffe1e560465665eb47d9264826f9", null ],
    [ "HAL_GPIO_EXTI_Callback", "main_beweginssensor_8c.html#a0cd91fd3a9608559c2a87a8ba6cba55f", null ],
    [ "HAL_TIM_PeriodElapsedCallback", "main_beweginssensor_8c.html#a8a3b0ad512a6e6c6157440b68d395eac", null ],
    [ "main", "main_beweginssensor_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "Sensor_aan", "main_beweginssensor_8c.html#a6c39c9e553ca221fd4bea17842e052c0", null ],
    [ "Sensor_uit", "main_beweginssensor_8c.html#a47969d53cfd212b640f70674c118f0a5", null ],
    [ "SystemClock_Config", "main_beweginssensor_8c.html#a70af21c671abfcc773614a9a4f63d920", null ],
    [ "beweging", "main_beweginssensor_8c.html#a7a55cf355d6683eafdd25aceab84d036", null ],
    [ "htim2", "main_beweginssensor_8c.html#a2c80fd5510e2990a59a5c90d745c716c", null ],
    [ "huart2", "main_beweginssensor_8c.html#aa9479c261d65eecedd3d9582f7f0f89c", null ],
    [ "lastButtonPressTime", "main_beweginssensor_8c.html#a4d7c964dc6845ae83da6263cb4e5c06a", null ]
];