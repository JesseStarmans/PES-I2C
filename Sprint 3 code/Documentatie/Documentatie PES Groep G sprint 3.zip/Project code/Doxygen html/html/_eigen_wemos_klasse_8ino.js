var _eigen_wemos_klasse_8ino =
[
    [ "getIPAddress", "_eigen_wemos_klasse_8ino.html#a2ad9bbcfaa97578139874f8bc202ba0f", null ],
    [ "loop", "_eigen_wemos_klasse_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "serverCode", "_eigen_wemos_klasse_8ino.html#a0feb8f324ebf27245792967858fdd630", null ],
    [ "setup", "_eigen_wemos_klasse_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "client", "_eigen_wemos_klasse_8ino.html#a7e7c1f8fd33b70e71d7a02da8af0f4e0", null ],
    [ "password", "_eigen_wemos_klasse_8ino.html#aa4a2ebcb494493f648ae1e6975672575", null ],
    [ "port", "_eigen_wemos_klasse_8ino.html#a0eb069d5f53d3e9269b0f321cfbcf108", null ],
    [ "server", "_eigen_wemos_klasse_8ino.html#ab8fb9986188a67f4b775f8f68da5a0de", null ],
    [ "serverIPaddress", "_eigen_wemos_klasse_8ino.html#aa8bac3b21dc37d6135a6d65080562708", null ],
    [ "serverPort", "_eigen_wemos_klasse_8ino.html#a2decc483ae2d615cfc10308e8a10ee85", null ],
    [ "ssid", "_eigen_wemos_klasse_8ino.html#a587ba0cb07f02913598610049a3bbb79", null ]
];