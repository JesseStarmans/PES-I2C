/*!
    @file mainwindow.h
    @brief Header file voor de MainWindow klasse.

    Deze header file definieert de klasse MainWindow voor het maken van een interface.
*/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>

#include <iostream>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE
//using namespace std;

class Indicator;
class SocketClient;
class SocketServer;
class Deur;

/*!
    @class MainWindow
    @brief Een klasse om een MainWindow aan te maken om een interface aan te maken.
*/
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event);

    ~MainWindow();
private slots:
    void handleVoordeur();
    void handleDeur1();
    void handleDeur2();

    void handleInvoerTekst();
    void handleSTMTekst();
    void handleSocketVoordeur(bool);
    void handleSocketDeur1(bool);
    void handleSocketDeur2(bool);
    // Temperatuur sensor update server
    void handleSocketTempSensor(std::string);
    // Co2 sensor
    void handleSocketCo2(std::string);
    // Plant sensor
    void handleSocketPlant(std::string);
    // Druk sensor
    void handleSocketDruk(std::string);
    //Get CO2
    void handleGetCO2();
    //Set CO2
    void handleSetCO2();

private:
    void initImage();

    Ui::MainWindow *ui;                                             /*!< UI object om de interface weer te geven.*/
    std::vector<std::shared_ptr<Deur>> deuren;                      /*!< Vector met deuren.*/
    std::vector<QPushButton*> buttons;                              /*!< Vector met buttons.*/
    std::vector<std::shared_ptr<Indicator>> indicatoren;            /*!< Vector met indicator bolletjes.*/
    QLineEdit* lichtkrantTekst;                                     /*!< Invoerveld voor de lichtkrant tekst.*/
    QLabel* lichtkrantWeergave;                                     /*!< Tekstveld voor de lichtkrant tekst.*/
    QLineEdit* temperatuurTekst;                                    /*!< Invoerveld voor het aanpassen van de gewenste temperatuur.*/
    QLabel* temperatuurWeergave;                                    /*!< Tekstveld voor de opgevraagde temperatuur.*/
    QLineEdit* CO2Set;                                              /*!< Invoerveld voor het aanpassen van de randwaarde voor de CO2*/
    QLabel* Co2Weergave;                                            /*!< Tekstveld voor de opgevraagde CO2-waarde.*/
    QPushButton* CO2Get;                                            /*!< Knop voor het opvragen van de CO2-waarde.*/
    SocketClient* client;                                           /*!< Client voor de socket verbinding naar de Pi server*/
    SocketServer* server;                                           /*!< Server voor de socket verbinding van de Pi*/
    QString IP;                                                     /*!< Het IP van het apparaat waar de interface op draait.*/
    QString imagePath;                                              /*!< Het pad naar het plaatje met de achtergrond.*/
    bool verwarming;                                                /*!< De status van de verwarming.*/
    double temperatuur;                                             /*!< De huidige temperatuur.*/
    int luchtvochtigheid;                                           /*!< De luchtvochtigheid.*/
    int Co2Level;                                                   /*!< De ingelezen hoeveelheid CO2.*/
    int Co2Alarm;                                                   /*!< De status van het alarm.*/
    int Co2Allowed = 800;                                           /*!< De hoeveelheid CO2 die toegestaan is.*/
};
#endif // MAINWINDOW_H
