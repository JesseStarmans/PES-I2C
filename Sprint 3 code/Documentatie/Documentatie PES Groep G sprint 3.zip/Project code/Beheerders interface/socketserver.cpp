/*!
    @file socketserver.cpp
	@date 25 May 2024
	@author Jesse Starmans
	@brief CPP file voor de QTSocketServer klasse.

    De implementatie van de QTSocketServer klasse.

    Deze klasse maakt het mogelijk om een socket server aan te maken, waarnaar verbonden kan worden door socket clients om data te versturen en ontvangen.

    Created on 14 May 2024
    by Jesse Starmans. \n 
    Modified on 16 May 2024
    by Jesse Starmans. \n
    Modified on 27 May 2024
    by Glenn de Jonge. \n 
    Modified on 31 May 2024
    by Jesse Starmans & Glenn de Jonge.
*/
#include "socketserver.h"
#include "defines.h"
#include <QCoreApplication>
#include <QDebug>
#include <string>

/*!
    @brief Constructor voor de QTSocketServer klasse.

    Deze constructor maak een QTSocketServer object aan.

    @param host Het IP adres waar de socket server naar moet gaan luisteren.
    @param port De pport waar de socket server naar moet gaan luisteren.
*/
QTSocketServer::QTSocketServer(QString host, quint16 port, QObject *parent) : QTcpServer(parent), IP(host), poort(port)
{
    connect(this, &SocketServer::newConnection, this, &SocketServer::handleNewConnection);
}

/*!
    @brief Destructor voor de QTSocketServer klasse.

    Deze destructor stopt de socket server en sloopt het QTSocketServer object.
*/
QTSocketServer::~QTSocketServer() {
    stopServer();
    qDeleteAll(clients.begin(), clients.end()); // Glenn: added want memory leak (27-05)
}

/*!
    @brief Start de socket server.

    Deze functie start de socket server op.
*/
void QTSocketServer::startServer()
{
    QHostAddress hostAddress(IP);
    if (!listen(hostAddress, poort)) {
        qDebug() << "Failed to start server:" << errorString();
        return;
    }
    qDebug() << "Server started, listening on port" << poort;
}

/*!
    @brief Stopt de socket server.

    Deze functie verbreekt eerst de verbindingen met de clients en stopt vervolgens de socket server.
*/
void QTSocketServer::stopServer()
{
    for (QTcpSocket* client : clients) {
        client->disconnectFromHost();
    }
    close();
}

/*!
    @brief Accepteert een nieuwe client verbinding.

    Deze functie wordt aangeroepen op het moment dat een client probeert te verbinden met de server.
*/
void QTSocketServer::handleNewConnection()
{
    while (hasPendingConnections()) {
        QTcpSocket* clientSocket = nextPendingConnection();
        qDebug() << "New connection from:" << clientSocket->peerAddress().toString();
        clients.append(clientSocket);
        connect(clientSocket, &QTcpSocket::readyRead, this, &SocketServer::readyRead);
        connect(clientSocket, &QTcpSocket::disconnected, clientSocket, &QTcpSocket::deleteLater);
    }
}

/*!
    @brief Checkt of er data binnengekomen is en leest dit in.

    Deze functie checkt of er data binnengekomen is van een client en leest dit dan in.
*/
void QTSocketServer::readyRead()
{
    QTcpSocket* clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (!clientSocket)
        return;

    QByteArray data = clientSocket->readAll();
    QString message = QString::fromUtf8(data);
    qDebug() << "Received message from" << clientSocket->peerAddress().toString() << ":" << message;

    // Voeg hier eventuele berichtverwerking toe of stuur het bericht naar alle andere clients
    checkReceived(message);
}

/*!
    @brief Stuurt de meegegeven QString naar alle clients.

    Deze functie stuurt de meegegeven QString naar alle clients die verbonden zijn met de server.

    @param message De te versturen QString.
*/
void QTSocketServer::sendMessageToClients(const QString& message)
{
    QByteArray byteArray = message.toUtf8();
    for (QTcpSocket* client : clients) {
        client->write(byteArray);
    }
}

/*!
    @brief Checkt wat er gedaan moet worden met de binnengekomen data.

    Deze functie checkt wat er gedaan moet worden met de meegegeven QString in de interface.
*/
void QTSocketServer::checkReceived(QString message) {
    int msg, key;
    qInfo() << message;

    std::string temp = message.toStdString().substr(0,5) ;
    qInfo() << temp;
    if(temp == "RTemp"){
        key = 200;
    }
    else if(temp == "Deur1") {
        key = 11;
    }
    else if(temp == "Deur2") {
        key = 12;
    }
    else if(temp == "RCO2:") {
        key = 203;
    }
    else if (temp == "Plant"){
        key = 210;
    }
    else if (temp == "RDruk"){
        key = 220;
    }
    else {
        key = 1000;
    }

    std::string secondPart = message.toStdString().substr(6); // rekening houden met spatie tussen firstPart en second
    qInfo() << secondPart;
    switch(key){
        case 10:
            qInfo() << "Voordeur open/dicht";
            emit Voordeur(DICHT);
            break;
        case 11:
            qInfo() << "Deur 1 open/dicht";
            emit Deur1(OPEN);
            emit Voordeur(OPEN);
            break;
        case 12:
            qInfo() << "Deur 2 open/dicht";
            emit Deur2(OPEN);
            emit Voordeur(OPEN);
            break;
        case 200:
            qInfo() << "Temperatuur update";
            emit Temperatuur(secondPart);
            break;
        case 203:
            qInfo() << "Co2 update";
            qInfo() << secondPart;
            emit Co2(secondPart);
            break;
        case 210:
            qInfo() << "Plant update";
            emit Plant(secondPart);
            break;
        case 220:
            qInfo() << "Druk update";
            emit Druk(secondPart);
            break;
        default:
            qInfo() << "Incorrect key";
    }

}

/*!
    @brief Zet een string om naar een int.

    Deze functie krijgt een string mee om te converteren naar een int. Mocht dit niet lukken wordt er een exception opgevangen.

    @return De geconverteerde int of -128 als er iets fout is gegaan.
*/
int SocketServer::toInt(const std::string& message){
/*
    todo: Verplaats dit naar een algemene class. Want is een beetje raar dat dit in SocketServer staat terwijl het ook in mainWindow wordt gebruikt
*/
    /*------------ Veilig string to int met exception handeling ----------*/
    try{
        return std::stoi(message);
    }catch(const std::invalid_argument&  invalid){
        qDebug() << invalid.what();
    }catch(const std::out_of_range& out){
        qDebug() << out.what();
    }catch(...){
        qDebug() << "Error receiving message";
    }
    return -128;
}