/*!
    @file indicator.h
    @brief Header file voor de Indicator klasse.

    Deze header file definieert de klasse Indicator voor het maken van een indicator bolletjes in de MainWindow.
*/
#ifndef INDICATOR_H
#define INDICATOR_H

class QPaintDevice;

/*!
    @class Indicator
    
    @brief Een klasse om een Indicator aan te maken om een bolletje in de MainWindow te kunnen maken met een aantal functionaliteiten. 
*/
class Indicator
{
public:
    Indicator(int, int, bool);
    ~Indicator();
    void teken(QPaintDevice*);
    void setOpen();
    void setDicht();
    void setStatus(int);
private:
    int xCoordinaat;        /*!< Het X-coordinaat van de indicator.*/
    int yCoordinaat;        /*!< Het Y-coordinaat van de indicator*/
    bool status;            /*!< De status van de indicator*/
};

#endif // INDICATOR_H
