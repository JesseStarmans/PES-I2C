/*!
    @file indicator.cpp
    @date 1 June 2024
    @author Jesse Starmans
    @brief CPP file voor de Indicator klasse

    De implementatie van de Indicator klasse.

    Deze klasse maakt het mogelijk om bolletjes te tekenen en hiermee de status van bepaalde handelingen weer te geven.

    Created on 4 May 2024
    by Jesse Starmans. \n
    Modified on 23 May 2024
    by Glenn de Jonge. \n 
*/
#include "indicator.h"
#include "Defines.h"
#include <QPaintDevice>
#include <QPainter>
#include <QPen>

/*!
    @brief Constructor voor de Indicator klasse.

    Deze constructor maakt een Indicator object aan.

    @param x De X-coordinaat van waar de indicator in de interface neergezet moet worden.
    @param y De Y-coordinaat van waar de indicator in de interface neergezet moet worden.
    @param s De status van de indicator waarin deze start.
*/
Indicator::Indicator(int x, int y, bool s): xCoordinaat(x), yCoordinaat(y), status(s) {

}

/*!
    @brief Destructor voor de Indicator klasse.

    Deze destructor sloopt het Indicator object.
*/
Indicator::~Indicator() {

}

/*!
    @brief Tekent de Indicator.

    Deze functie tekent de indicator in de MainWindow.

    @param tp Het object dat getekend moet worden.
*/
void Indicator::teken(QPaintDevice* tp) {
    QPainter p(tp);
    QColor kleur;
    p.setRenderHint(QPainter::Antialiasing);
    p.setBrush(Qt::SolidPattern);
    if(status == OPEN)
        kleur=Qt::red;
    else
        kleur=Qt::blue;

    p.setBrush(kleur);
    QPen pen(kleur,2,Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    p.setPen(pen);
    p.drawEllipse(xCoordinaat, yCoordinaat,20,20);
}

/*!
    @brief Zet de status op OPEN (true).

    Deze functie past de status van de Indicator aan naar OPEN.
*/
void Indicator::setOpen() {
    status = OPEN;
}

/*!
    @brief Zet de status op DICHT (false).

    Deze functie past de status van de Indicator aan naar DICHT.
*/
void Indicator::setDicht() {
    status = DICHT;
}

/*!
    @brief Zet de status naar de meegeven status.

    Deze functie past de status van de Indicator aan naar de meegegeven status.
*/
void Indicator::setStatus(int stat){
    status = stat;
}
